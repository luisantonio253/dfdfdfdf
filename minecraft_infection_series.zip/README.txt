
===========================================================
MINECRAFT INFECTION SERIES
===========================================================

Paper + Skript + SkBee + Resource Pack

===========================================================
MECÂNICA
===========================================================

1. Matar um zumbi infecta o jogador.

2. /infectar <jogador>

Inicia uma transmissão.

3. Durante a transmissão:

O infectador precisa permanecer parado.

Se ele se mover:

    INFECTADOR = NÍVEL 5
    ALVO       = NÍVEL 5

4. Nível 5 inicia a transformação.

5. A transformação ocorre em fases:

    Fase 1 - olhos começam a mudar
    Fase 2 - olhos totalmente infectados
    Fase 3 - corpo começa a mudar
    Fase 4 - mutação avançada
    Fase 5 - zumbi completo

6. A Essência Anti-Zumbi funciona até a transformação
   terminar.

7. Depois de virar zumbi completo:

    Essência = NÃO FUNCIONA

===========================================================
COMANDOS
===========================================================

/essencia

Recebe a Essência Anti-Zumbi.

Comando administrativo.

-----------------------------------------------------------

/infectar <jogador>

Transmite a infecção.

-----------------------------------------------------------

/infeccao

Mostra sua infecção.

-----------------------------------------------------------

/infeccao <jogador>

Mostra a infecção de outro jogador.

-----------------------------------------------------------

/setinfection <jogador> <0-6>

Define o nível manualmente.

===========================================================
RESOURCE PACK
===========================================================

A textura da Essência está em:

assets/infection/textures/item/

O modelo está em:

assets/infection/models/item/

O item usa Custom Model Data 10001.

===========================================================
IMPORTANTE
===========================================================

O Resource Pack controla a aparência do item.

Para transformar visualmente o jogador inteiro em um
zumbi, é necessário um sistema adicional de modelo/
disguise compatível com a versão exata do servidor.

===========================================================
